"""A mock extension named `mock3` for testing purposes."""


def _load_jupyter_server_extension(serverapp):
    pass
